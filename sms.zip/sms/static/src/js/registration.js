// form visible
$('#academic_info_btn').on('click', function(){
  $('.academic_info').hide();
  $('.personal_info').show();
});

// Presonal Information
$('#personal_info_btn').on('click', function(){
  $('.personal_info').hide();
  $('.address_info').show();
});

$('#personal_info_prev_btn').on('click', function(){
  $('.personal_info').hide();
  $('.academic_info').show();
});

 