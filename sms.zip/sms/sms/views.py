from django.shortcuts import render
from django.contrib.auth.decorators import login_required
import student
import teacher


@login_required(login_url='login')
def home_page(request):
    total_student = student.models.studentdata.objects.count() - student.models.studentdata.objects.filter(is_delete=True).count()
    total_teacher= teacher.models.teacherdata.objects.count() - teacher.models.teacherdata.objects.filter(is_delete=True).count()
    
    context = {
        'student': total_student,
        'teacher': total_teacher,		
        
    }
    return render(request, 'home.html', context)

