from django.shortcuts import render, redirect
from .models import studentdata
from . import forms




def student_registration(request):
    
    form = forms.PersonalInfoForm()
    
    
    if request.method == 'POST':
        form = forms.PersonalInfoForm(request.POST, request.FILES)
 
        if form.is_valid():
             
            personal_info = form.save(commit=False)
            personal_info.save()
            return redirect('student-list')

    context = {
        'form': form,   
    }
    return render(request, 'student/student-registration.html', context)




def student_list(request):
    student = studentdata.objects.filter(is_delete=False)
    context = {'student': student}
    return render(request, 'student/student-list.html', context)

def student_profile(request, Roll_no):
    student = studentdata.objects.get(Roll_no=Roll_no)
    context = {
        'student': student
    }
    return render(request, 'student/student-profile.html', context)

def student_delete(request, Roll_no):
    student = studentdata.objects.get(Roll_no=Roll_no)
    student.is_delete = True
    student.save()
    return redirect('student-list')
	
	
def student_edit(request, Roll_no):
    student = studentdata.objects.get(Roll_no=Roll_no)
    form = forms.PersonalInfoForm(instance=student)
 
    
    if request.method == 'POST':
        form = forms.PersonalInfoForm(request.POST, request.FILES, instance=student)
        
        if form.is_valid():
            personal_info = form.save(commit=False)
            personal_info.save()
            return redirect('student-list')
    context = {
        'form': form,       
    }   
 
    return render(request, 'student/student-edit.html', context)
