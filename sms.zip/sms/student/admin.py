from django.contrib import admin
from .models import studentdata
# Register your models here.

admin.site.register(studentdata)