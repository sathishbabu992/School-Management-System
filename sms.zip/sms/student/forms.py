from django import forms
from . import models
from .models import studentdata


class PersonalInfoForm(forms.ModelForm):
    class Meta:
        model = models.studentdata
        exclude = {'is_delete'}
        widgets = {
			'class_name': forms.TextInput(attrs={'class': 'form-control'}),
			'Roll_no':forms.TextInput(attrs={'class': 'form-control'}),
            'name': forms.TextInput(attrs={'class': 'form-control'}),
            'photo': forms.ClearableFileInput(attrs={'class': 'form-control'}),
            'date_of_birth': forms.DateInput(attrs={'class': 'form-control'}),
            'gender': forms.Select(attrs={'class': 'form-control'}),
            'phone_no': forms.NumberInput(attrs={'class': 'form-control'}),
            'email': forms.EmailInput(attrs={'class': 'form-control'}),
            'father_name': forms.TextInput(attrs={'class': 'form-control'}),
            'address': forms.TextInput(attrs={'class': 'form-control'}),
			'student_performance': forms.TextInput(attrs={'class': 'form-control'}),
			'Student_type': forms.TextInput(attrs={'class': 'form-control'}),
			'date': forms.DateInput(attrs={'class': 'form-control'}),

        }