from django.db import models
from datetime import datetime
# Create your models here.


class studentdata(models.Model):
    class_name = models.CharField(max_length=50)
    Roll_no = models.CharField(max_length=50)
    name = models.CharField(max_length=100)
    photo = models.ImageField()
    date_of_birth = models.DateField()
    gender_choice = (
        ('male', 'Male'),
        ('female', 'Female'),
        ('other', 'Other')
            )
    gender = models.CharField(choices=gender_choice, max_length=10)
    phone_no = models.CharField(max_length=11, unique=True)
    email = models.CharField(max_length=255, unique=True)
    father_name = models.CharField(max_length=45)
    address = models.TextField()
    student_performance = models.CharField(max_length=100)
    Student_type = models.CharField(max_length=100)
    is_delete = models.BooleanField(default=False)
    date = models.DateTimeField(default = datetime.now, blank=True)
 
    def __str__(self):
        return self.name
    
   

