from django.contrib import admin

from .models import ManageExams


class ManageExamsAdmin(admin.ModelAdmin):
	list_display = ('id', 'exam_name', 'subject', 'subject_code', 'exam_date')
	list_filter = ('exam_name', 'exam_date')

admin.site.register(ManageExams, ManageExamsAdmin) 