from django.shortcuts import render, redirect

from .models import teacherdata
from . import forms

# Create your views here.

def teacher_registration(request):
    form = forms.PersonalInfoForm()
    
    
    if request.method == 'POST':
        form = forms.PersonalInfoForm(request.POST, request.FILES)
 
        if form.is_valid():
             
            personal_info = form.save(commit=False)
            personal_info.save()
            return redirect('teacher-list')

    context = {
        'form': form,   
    }
    return render(request, 'teacher/teacher-registration.html', context)




def teacher_list(request):
    teacher = teacherdata.objects.filter(is_delete=False)
    context = {'teacher': teacher}
    return render(request, 'teacher/teacher-list.html', context)
	
def teacher_profile(request, teacher_id):
    teacher = teacherdata.objects.get(id=teacher_id)
    context = {
        'teacher': teacher
    }
    return render(request, 'teacher/teacher-profile.html', context)

def teacher_delete(request, teacher_id):
    teacher = teacherdata.objects.get(id=teacher_id)
    teacher.is_delete = True
    teacher.save()
    return redirect('teacher-list')
	
def teacher_edit(request, teacher_id):
    teacher = teacherdata.objects.get(id=teacher_id)
    form = forms.PersonalInfoForm(instance=teacher)
 
    
    if request.method == 'POST':
        form = forms.PersonalInfoForm(request.POST, request.FILES, instance=teacher)
        
        if form.is_valid():
            personal_info = form.save(commit=False)
            personal_info.save()
            return redirect('teacher-list')
    context = {
        'form': form,       
    }
    return render(request, 'teacher/teacher-edit.html', context)
	