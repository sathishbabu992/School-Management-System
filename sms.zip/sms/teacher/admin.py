from django.contrib import admin
from .models import teacherdata
# Register your models here.


class teacherdataAdmin(admin.ModelAdmin):
	list_display = ('id', 'name', 'gender', 'teaching_subject', 'is_delete')
	list_filter = ('name', 'teaching_subject', 'is_delete')

admin.site.register(teacherdata, teacherdataAdmin)
