from django import forms
from . import models
from .models import teacherdata


class PersonalInfoForm(forms.ModelForm):
    class Meta:
        model = models.teacherdata
        exclude = {'is_delete'}
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control'}),
            'photo': forms.ClearableFileInput(attrs={'class': 'form-control'}),
            'date_of_birth': forms.DateInput(attrs={'class': 'form-control'}),
            'gender': forms.Select(attrs={'class': 'form-control'}),
            'phone_no': forms.NumberInput(attrs={'class': 'form-control'}),
            'email': forms.EmailInput(attrs={'class': 'form-control'}),
            'father_name': forms.TextInput(attrs={'class': 'form-control'}),
            'address': forms.TextInput(attrs={'class': 'form-control'}),
			'education': forms.TextInput(attrs={'class': 'form-control'}),
			'teaching_subject': forms.TextInput(attrs={'class': 'form-control'}),
			'date': forms.DateInput(attrs={'class': 'form-control'}),

        }